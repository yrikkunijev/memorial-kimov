# Мемориальный сайт Кимова Тембота Эльмурзовича

## Инструкция по загрузке на GitHub Pages

1. Зайдите в свой репозиторий: https://github.com/yrikkunijev/memorial-kimov
2. Нажмите **Add file → Upload files**.
3. Загрузите все файлы из этого архива (включая папку `assets`).
4. После загрузки нажмите **Commit changes**.
5. Перейдите в **Settings → Pages**.
6. В разделе "Branch" выберите `main` и корневую директорию `/ (root)`.
7. Сохраните настройки.
8. Через 1–2 минуты сайт будет доступен по адресу:  
   👉 https://yrikkunijev.github.io/memorial-kimov/

## Контакты и комментарии

Форма комментариев отправляет сообщения на e-mail: `yrikkunijev@gmail.com` через Formsubmit.co.

